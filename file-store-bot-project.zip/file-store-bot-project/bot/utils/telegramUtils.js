const axios = require('axios');
const botConfig = require('../config/botConfig');

// Function to send a message via the bot
const sendMessage = async(chatId, text) => {
    try {
        const url = `https://api.telegram.org/bot${botConfig.token}/sendMessage`;
        await axios.post(url, {
            chat_id: chatId,
            text: text
        });
    } catch (error) {
        console.error('Error sending message:', error);
    }
};

// Function to send a file via the bot
const sendFile = async(chatId, filePath) => {
    try {
        const url = `https://api.telegram.org/bot${botConfig.token}/sendDocument`;
        await axios.post(url, {
            chat_id: chatId,
            document: filePath
        });
    } catch (error) {
        console.error('Error sending file:', error);
    }
};

module.exports = {
    sendMessage,
    sendFile
};