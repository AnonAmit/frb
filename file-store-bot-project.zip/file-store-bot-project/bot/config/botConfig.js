module.exports = {
    token: process.env.TELEGRAM_BOT_TOKEN // Ensure you have this environment variable set
};