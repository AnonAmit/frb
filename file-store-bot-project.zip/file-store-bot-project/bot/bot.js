const TelegramBot = require('node-telegram-bot-api');
const botConfig = require('./config/botConfig');

// Create a new bot instance
const bot = new TelegramBot(botConfig.token, { polling: true });

// Handle incoming messages
bot.on('message', async(msg) => {
    const chatId = msg.chat.id;
    const text = msg.text;

    // Handle commands or other message types
    if (text === '/start') {
        bot.sendMessage(chatId, 'Welcome to the File Store Bot! Use /help to see available commands.');
    } else if (text === '/help') {
        bot.sendMessage(chatId, 'Available commands:\n/start - Start the bot\n/help - Show help');
    } else {
        bot.sendMessage(chatId, 'Command not recognized. Type /help for a list of commands.');
    }
});

module.exports = bot;