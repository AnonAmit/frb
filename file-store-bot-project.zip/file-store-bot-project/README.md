### 20. `README.md`

```markdown
# File Store Bot Project

## Overview
This project is a File Store Bot system that includes a backend, frontend, and Telegram bot. Users can interact with multiple bots through a central link, make payments, and access files. 

## Project Structure

- `backend/`: Contains the server-side code.
  - `config/`: Configuration files, including database and bot configuration.
  - `controllers/`: Business logic for bots, payments, and file handling.
  - `routes/`: API routes for bots, payments, and files.
  - `models/`: Mongoose models for bots, users, and payments.
  - `server.js`: Main server entry point.

- `frontend/`: Contains the client-side code.
  - `public/`: Publicly accessible files, including the main HTML file.
  - `src/`: Source code for React components and application logic.

- `bot/`: Contains the Telegram bot logic.
  - `config/`: Configuration for the Telegram bot.
  - `utils/`: Utility functions for interacting with the Telegram API.

## Getting Started

### Prerequisites
- Node.js and npm installed
- MongoDB instance running
- Telegram Bot Token (set in environment variables)

### Installation

1. **Clone the repository:**
   ```bash
   git clone https://github.com/your-repository-url.git
   cd your-repository-name
   ```

2. **Backend Setup:**
   ```bash
   cd backend
   npm install
   cp .env.example .env
   # Set your environment variables in .env
   npm start
   ```

3. **Frontend Setup:**
   ```bash
   cd ../frontend
   npm install
   npm start
   ```

4. **Bot Setup:**
   ```bash
   cd ../bot
   npm install
   # Start the bot (if applicable)
   ```

## Usage

- **Backend API:** Access the backend API at `http://localhost:5000/api`
- **Frontend:** Access the frontend application at `http://localhost:3000`
- **Bot:** The bot should be running and connected to Telegram.

## License
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
```

This `README.md` provides an overview of the project, setup instructions, and usage details. Make sure to replace placeholders with actual values as needed.

Let me know if there's anything else you need!