const express = require('express');
const router = express.Router();
const { getFile, uploadFile } = require('../controllers/fileController');

// Route to get a file
router.get('/files/:filename', getFile);

// Route to upload a file
router.post('/files/upload', uploadFile);

module.exports = router;