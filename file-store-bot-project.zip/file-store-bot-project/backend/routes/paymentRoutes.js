const express = require('express');
const router = express.Router();
const { verifyPayment, activateMembership } = require('../controllers/paymentController');

// Route to verify payment
router.post('/payment/verify', verifyPayment);

// Route to activate membership
router.post('/payment/activate-membership', activateMembership);

module.exports = router;