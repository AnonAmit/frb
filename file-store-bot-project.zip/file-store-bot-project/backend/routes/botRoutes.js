const express = require('express');
const router = express.Router();
const { createBot, getBots, deleteBot } = require('../controllers/botController');

// Route to create a new bot
router.post('/bots', createBot);

// Route to get all bots
router.get('/bots', getBots);

// Route to delete a bot
router.delete('/bots/:id', deleteBot);

module.exports = router;