const path = require('path');
const fs = require('fs');

// Controller to deliver a file
exports.getFile = async(req, res) => {
    try {
        const filePath = path.join(__dirname, '..', 'files', req.params.filename);

        if (fs.existsSync(filePath)) {
            res.sendFile(filePath);
        } else {
            res.status(404).json({ success: false, message: 'File not found' });
        }
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// Controller to handle file upload (for future use)
exports.uploadFile = async(req, res) => {
    try {
        const file = req.files.file;
        const uploadPath = path.join(__dirname, '..', 'files', file.name);

        file.mv(uploadPath, (err) => {
            if (err) {
                return res.status(500).json({ success: false, message: err.message });
            }
            res.status(200).json({ success: true, message: 'File uploaded successfully' });
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};