const Payment = require('../models/Payment');
const axios = require('axios');

// Controller to handle payment verification
exports.verifyPayment = async(req, res) => {
    try {
        const { paymentId, amount } = req.body;

        // Example URL, replace with your actual Cashfree verification endpoint
        const response = await axios.post('https://example-cashfree-url.com/verify', {
            paymentId,
            amount
        });

        if (response.data.success) {
            const payment = new Payment({ paymentId, amount, verified: true });
            await payment.save();
            res.status(200).json({ success: true, data: payment });
        } else {
            res.status(400).json({ success: false, message: 'Payment verification failed' });
        }
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// Controller to activate a 24-hour membership
exports.activateMembership = async(req, res) => {
    try {
        const { userId } = req.body;
        // Add logic to activate membership for 24 hours
        // This is a placeholder response
        res.status(200).json({ success: true, message: 'Membership activated for 24 hours' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};