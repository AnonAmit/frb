const Bot = require('../models/Bot');

// Controller to create a new bot
exports.createBot = async(req, res) => {
    try {
        const bot = new Bot(req.body);
        await bot.save();
        res.status(201).json({ success: true, data: bot });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// Controller to get all bots
exports.getBots = async(req, res) => {
    try {
        const bots = await Bot.find();
        res.status(200).json({ success: true, data: bots });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// Controller to delete a bot
exports.deleteBot = async(req, res) => {
    try {
        const bot = await Bot.findByIdAndDelete(req.params.id);
        if (!bot) {
            return res.status(404).json({ success: false, message: 'Bot not found' });
        }
        res.status(200).json({ success: true, data: {} });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};