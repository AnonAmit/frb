import React from 'react';
import BotManagement from './components/BotManagement';
import PaymentModal from './components/PaymentModal';
import BroadcastSection from './components/BroadcastSection';

function App() {
    return ( <
        div className = "App" >
        <
        h1 > File Store Bot < /h1> <
        BotManagement / >
        <
        PaymentModal / >
        <
        BroadcastSection / >
        <
        /div>
    );
}

export default App;