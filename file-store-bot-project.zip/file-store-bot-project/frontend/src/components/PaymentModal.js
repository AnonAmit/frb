import React, { useState } from 'react';
import axios from 'axios';

function PaymentModal() {
    const [paymentId, setPaymentId] = useState('');
    const [amount, setAmount] = useState('');
    const [status, setStatus] = useState('');

    const handleVerifyPayment = async() => {
        try {
            const response = await axios.post('/api/payment/verify', { paymentId, amount });
            if (response.data.success) {
                setStatus('Payment verified successfully.');
            } else {
                setStatus('Payment verification failed.');
            }
        } catch (error) {
            setStatus('Error verifying payment.');
            console.error('Error verifying payment:', error);
        }
    };

    return ( <
        div className = "payment-modal" >
        <
        h2 > Verify Payment < /h2> <
        input type = "text"
        value = { paymentId }
        onChange = {
            (e) => setPaymentId(e.target.value) }
        placeholder = "Payment ID"
        required /
        >
        <
        input type = "number"
        value = { amount }
        onChange = {
            (e) => setAmount(e.target.value) }
        placeholder = "Amount"
        required /
        >
        <
        button onClick = { handleVerifyPayment } > Verify Payment < /button> {
            status && < p > { status } < /p>} <
                /div>
        );
    }

    export default PaymentModal;