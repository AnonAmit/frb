import React, { useState } from 'react';
import axios from 'axios';

function BroadcastSection() {
    const [message, setMessage] = useState('');
    const [status, setStatus] = useState('');

    const handleBroadcast = async() => {
        try {
            const response = await axios.post('/api/broadcast', { message });
            if (response.data.success) {
                setStatus('Message broadcasted successfully.');
                setMessage('');
            } else {
                setStatus('Broadcast failed.');
            }
        } catch (error) {
            setStatus('Error broadcasting message.');
            console.error('Error broadcasting message:', error);
        }
    };

    return ( <
        div className = "broadcast-section" >
        <
        h2 > Broadcast Message < /h2> <
        textarea value = { message }
        onChange = {
            (e) => setMessage(e.target.value) }
        placeholder = "Enter your message here"
        rows = "4"
        cols = "50" /
        >
        <
        button onClick = { handleBroadcast } > Broadcast < /button> {
            status && < p > { status } < /p>} <
                /div>
        );
    }

    export default BroadcastSection;