import React, { useState, useEffect } from 'react';
import axios from 'axios';

function BotManagement() {
    const [bots, setBots] = useState([]);
    const [newBot, setNewBot] = useState({ name: '', token: '', description: '' });

    useEffect(() => {
        async function fetchBots() {
            try {
                const response = await axios.get('/api/bots');
                setBots(response.data.data);
            } catch (error) {
                console.error('Error fetching bots:', error);
            }
        }
        fetchBots();
    }, []);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setNewBot({...newBot, [name]: value });
    };

    const handleSubmit = async(e) => {
        e.preventDefault();
        try {
            await axios.post('/api/bots', newBot);
            setNewBot({ name: '', token: '', description: '' });
            const response = await axios.get('/api/bots');
            setBots(response.data.data);
        } catch (error) {
            console.error('Error adding bot:', error);
        }
    };

    const handleDelete = async(id) => {
        try {
            await axios.delete(`/api/bots/${id}`);
            const response = await axios.get('/api/bots');
            setBots(response.data.data);
        } catch (error) {
            console.error('Error deleting bot:', error);
        }
    };

    return ( <
        div >
        <
        h2 > Manage Bots < /h2> <
        form onSubmit = { handleSubmit } >
        <
        input type = "text"
        name = "name"
        value = { newBot.name }
        onChange = { handleInputChange }
        placeholder = "Bot Name"
        required /
        >
        <
        input type = "text"
        name = "token"
        value = { newBot.token }
        onChange = { handleInputChange }
        placeholder = "Bot Token"
        required /
        >
        <
        textarea name = "description"
        value = { newBot.description }
        onChange = { handleInputChange }
        placeholder = "Bot Description" /
        >
        <
        button type = "submit" > Add Bot < /button> <
        /form> <
        ul > {
            bots.map((bot) => ( <
                li key = { bot._id } >
                <
                strong > { bot.name } < /strong> - {bot.description} <
                button onClick = {
                    () => handleDelete(bot._id) } > Delete < /button> <
                /li>
            ))
        } <
        /ul> <
        /div>
    );
}

export default BotManagement;